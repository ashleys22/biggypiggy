package BiggyPiggy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DatabaseManager {
	public static int getGoal() {
		int goal = 0;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String queryString = "Select * from Finacnes";
		
		try {
			conn = DriverManager.getConnection("jdbc:mysql://google/Piggy?cloudSqlInstance=biggy-piggy:us-central1:root&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false&user=root&password=password");
			ps = conn.prepareStatement(queryString);
			rs = ps.executeQuery();
			while(rs.next()) {
				goal  = rs.getInt("goal");
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			}
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		return goal;
	}
	
	public static void updateGoal(int value, String date, int savings, int budget) {
		//Connect to database
				Connection conn = null;
				PreparedStatement ps = null;
				ResultSet rs = null;
				
				
				String updateString = "UPDATE Finacnes SET goal = ?, date = ?, savings = ?, budget = ? WHERE entryID = 1";
				
				try {
					conn = DriverManager.getConnection("jdbc:mysql://google/Piggy?cloudSqlInstance=biggy-piggy:us-central1:root&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false&user=root&password=password");
					ps = conn.prepareStatement(updateString);
					ps.setInt(1, value); //updates count
					ps.setString(2, date);
					ps.setInt(3, savings);
					ps.setInt(4, budget);
					ps.executeUpdate();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
				finally {
					try {
						if (rs != null) {
							rs.close();
						}
						if (ps != null) {
							ps.close();
						}
						if (conn != null) {
							conn.close();
						}
					}
					catch (SQLException sqle) {
						System.out.println("sqle: " + sqle.getMessage());
					}
				}
	}
	
	public static void addEntry(int value, String date, String type) {
		//Connect to database
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String newEntryString = "INSERT INTO entries (value, date, type) VALUES(?, ?, ?)";
		
		try {
			conn = DriverManager.getConnection("jdbc:mysql://google/Piggy?cloudSqlInstance=biggy-piggy:us-central1:root&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false&user=root&password=password");
			ps = conn.prepareStatement(newEntryString);
			ps.setInt(1, value);
			ps.setString(2, date);
			ps.setString(3, type);
			ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			}
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
	}
	
	public static ArrayList<Entry> getEntries() {
		ArrayList<Entry> data = new ArrayList<Entry>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String getDataString = "SELECT * from entries";
		
		try {
			conn = DriverManager.getConnection("jdbc:mysql://google/Piggy?cloudSqlInstance=biggy-piggy:us-central1:root&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false&user=root&password=password");
			ps = conn.prepareStatement(getDataString);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				int value  = rs.getInt("value");
				String date = rs.getString("date");
				String type = rs.getString("type");
	
				Entry entry = new Entry(value, date, type);
				data.add(entry);
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			}
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		return data;
	}

}