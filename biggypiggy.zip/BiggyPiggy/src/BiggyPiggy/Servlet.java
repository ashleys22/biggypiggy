package BiggyPiggy;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet
 */
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int value = Integer.parseInt(request.getParameter("value"));
		String date = request.getParameter("date");
		String type = request.getParameter("type");
		
		if (type.equalsIgnoreCase("goal")) {
			int savings = Integer.parseInt(request.getParameter("savings"));
			int budget = Integer.parseInt(request.getParameter("budget"));
			DatabaseManager.updateGoal(value, date, savings, budget);
		}
		
		else {
			DatabaseManager.addEntry(value, date, type);
		}
	}

}
