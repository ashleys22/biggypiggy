package BiggyPiggy;

public class Entry {
	private String date;
	private int value;
	private String type;

	public Entry(int value, String date, String type) {
		this.value = value;
		this.date = date;
		this.type = type;
	}

	public int getValue() {
		return value;
	}

	public String getDate() {
		return date;
	}

	public String getType() {
		return type;
	}
}
