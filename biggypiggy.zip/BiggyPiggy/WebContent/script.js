$(function () {
		$('[data-toggle="popover"]').popover()
})

$("#back").on("click", function() {
	window.location="home.jsp";
});

let savings = parseInt(localStorage.getItem("savings"));
let goal = parseInt(localStorage.getItem("goal"));
var percent;
if (savings*100/goal > 100) {
	percent = 100;
}
else percent = savings*100/goal;
$("#progress").text(percent + "%");
$("#progress").css("width", percent + "%");

if (percent >= 100)
{
	$("#pig-img").attr("src", "richPig.gif");
}
else if (percent >= 50)
{
	$("#pig-img").attr("src", "midPig.gif");
}
else
{
	$("#pig-img").attr("src", "sadPig.gif");
}

if (localStorage.getItem("budget")) {
	let budget = parseInt(localStorage.getItem("budget"));
	$(".budget").text(budget);
}
if (localStorage.getItem("savings")) {
	let savings = parseInt(localStorage.getItem("savings"));
	$("#pig-amount").text(savings);
}


$(function () {
	$('[data-toggle="popover"]').popover();
})

function getDate() {
	var today = new Date();
	var dd = String(today.getDate()).padStart(2, '0');
	var mm = String(today.getMonth() + 1).padStart(2, '0');
	var yyyy = today.getFullYear();
	today = mm + '/' + dd + '/' + yyyy;
	return today;
}

function ajax(value, date, type) {		
	var xhr = new XMLHttpRequest();
	let url = 'Servlet?value=' + value + '&date=' + date + '&type=' + type;
    xhr.open('GET', url);
    xhr.send();
}

function ajax2(value, date, savings, budget) {		
	var xhr = new XMLHttpRequest();
	let url = 'Servlet?value=' + value + '&date=' + date + '&type=goal' + '&savings=' + savings + '&budget=' + budget;
	console.log(url);
    xhr.open('GET', url);
    xhr.send();
}

$("#save-button").on("click", function() {
	$("#overlay").css("display", "block");
	$("#save-popup").css("display", "block");
});

$("#earn-button").on("click", function() {
	$("#overlay").css("display", "block");
	$("#deposit-popup").css("display", "block");
});

$("#spend-button").on("click", function() {
	$("#overlay").css("display", "block");
	$("#spend-popup").css("display", "block");
});

$("#add").on("click", function() {
	$("#overlay").css("display", "block");
	$("#goal-popup").css("display", "block");
});

$("#save-form").on("submit", function() {
	let value = parseInt($("#save").val());
	let budget = parseInt($(".budget").text());
	if (budget - value < 0) {
		alert("You don't have enough money!");
	}
	else {
		let newBudget = budget - value;
		let newSavings = parseInt($("#pig-amount").text()) + value;
		$(".budget").text(newBudget);
		$("#pig-amount").text(newSavings);
		localStorage.setItem("budget", newBudget);
		localStorage.setItem("savings", newSavings);
		ajax(value, getDate(), "Saving");
	}
});

$("#deposit-form").on("submit", function() {
	let value = parseInt($("#earn").val());
	let budget = parseInt($(".budget").text());
	$(".budget").text(budget + value);
	localStorage.setItem("budget", budget+value);
	console.log(budget+value);
	ajax(value, getDate(), "Earning");
});

$("#spend-form").on("submit", function() {
	let value = parseInt($("#spending").val());
	let budget = parseInt($(".budget").text());
	let savings = parseInt($("#pig-amount").text());
	if (budget - value < 0) {
		if ((savings - (value - budget)) < 0) {
			alert("You don't have enough money!");
			return;
		}
		else {
			let newSavings = savings - (value - budget);
			$(".budget").text(0);
			$("#pig-amount").text(newSavings);
			localStorage.setItem("budget", 0);
			localStorage.setItem("savings", newSavings);
		}
	}
	else {
		$(".budget").text(budget - value);
		localStorage.setItem("budget", budget - value);
	}
	ajax(value, getDate(), "Spending");
});

$("#goal-form").on("submit", function() {
	let value = parseInt($("#goal").val());
	localStorage.setItem("goal", value);
	var date = document.querySelector('input[type="date"]');
	let savings = $("#pig-amount").text();
	let budget = $(".budget").text();
	ajax2(value, date, savings, budget);
});




